﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Hodiny
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Timer.Interval = TimeSpan.FromMilliseconds(100);
            Timer.Tick += Timer_Tick;
            Timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            HodinovaRuc.RenderTransform = new RotateTransform(DateTime.Now.Hour * 30 + DateTime.Now.Minute / 2);
            MinutovaRuc.RenderTransform = new RotateTransform(DateTime.Now.Minute * 6);
            SekundovaRuc.RenderTransform = new RotateTransform(DateTime.Now.Second * 6);
            TBox.Text = DateTime.Now.Day.ToString() + ". " + DateTime.Now.Month.ToString() + ". " + DateTime.Now.Year.ToString();
            TBox2.Text = DateTime.Now.DayOfWeek.ToString();
            Des++;
            if(Des == 10)
            {
                Des = 0;
                Sek++;
            }
            if(Sek == 60)
            {
                Sek = 0;
                Min++;
            }
            DesRuc.RenderTransform = new RotateTransform(Des * 36);
            SekRuc.RenderTransform = new RotateTransform(Sek * 6);
            MinRuc.RenderTransform = new RotateTransform(Min * 6);

        }

        DispatcherTimer Timer = new DispatcherTimer();
        int Des = 0;
        int Sek = 0;
        int Min = 0;
        
        
    }
}
